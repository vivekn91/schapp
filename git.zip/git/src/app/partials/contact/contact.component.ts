import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  lat: number = 11.455799;
  lng: number = 77.433868;

  constructor() { }

  ngOnInit() {
  }

}
